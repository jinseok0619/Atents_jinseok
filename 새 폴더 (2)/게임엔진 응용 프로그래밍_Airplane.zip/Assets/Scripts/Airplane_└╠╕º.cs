using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Airplane_이름 : MonoBehaviour
{
    public float rotateSpeed = 720.0f;
    public float moveSpeed = 5.0f;

    Transform[] waypoints;
    Transform propeller;
    int targetIndex = 0;

    private void Awake()
    {
        waypoints = new Transform[2];
        waypoints[0] = GameObject.Find("Waypoint1").transform;
        waypoints[1] = GameObject.Find("Waypoint2").transform;

    }

    private void Start()
    {
    }

    private void Update()
    {
    }

    void GoNextWaypoint()
    {
    }

}
